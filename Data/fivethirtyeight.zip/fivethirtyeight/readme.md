fivethirtyeight
===============

This folder contains three datasets derived from [the fivethirtyeight package](https://mran.microsoft.com/web/packages/fivethirtyeight/vignettes/fivethirtyeight.html) created by Albert Y. Kim, Chester Ismay, and Jennifer Chunn (2017).
