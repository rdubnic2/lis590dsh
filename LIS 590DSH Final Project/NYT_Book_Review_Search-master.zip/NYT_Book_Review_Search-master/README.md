# NYT_Book_Review_Search
An interface using the New York Times API to search book reviews and return a list of results formatted with jQuery Template with descriptions and links to the full reviews
